﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop
{
    public partial class ChiTietMaster : System.Web.UI.MasterPage
    {
        COMMON cm = new COMMON();
        public String strLogin;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["UserName"] == null)
            {
                strLogin += "<li><a data-modal='modalTwo' class='button'>Đăng ký</a></li> ";
                strLogin += "<li><a data-modal='modalOne' class='button'>Đăng nhập</a></li>";
            }
            else
            {
                strLogin = "<li  id = 'dd' class='cart1 wrapper-dropdown-2'>";
                login();
                strLogin += "</li>";
            }
        }
        public void login()
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select * from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
            DataTable tb = cm.getTable(userid);
            string makh = ""; int group_id = 0;
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
                group_id = Convert.ToInt16(row["Group_ID"].ToString());
            }
            string data = "Select * from tbTHONGTINCANHAN";
            DataTable tb1 = cm.getTable(data);
            string ca_id = "";
            foreach (DataRow row in tb1.Rows)
            {
                ca_id = row["KH_ID"].ToString();
            }
            if (makh.Equals(ca_id) == false)
            {
                if (group_id == 1)
                {
                    foreach (DataRow row in tb.Rows)
                    {

                        strLogin += "Welcome to " + row["UserName"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["UserName"].ToString();
                    }
                }
                else if (group_id == 2)
                {
                    foreach (DataRow row in tb.Rows)
                    {

                        strLogin += "Welcome to " + row["UserName"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='../ManagementShop/UserGrant.aspx'>Khu vực admin</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["UserName"].ToString();
                    }
                }
                else
                {
                    foreach (DataRow row in tb.Rows)
                    {

                        strLogin += "Welcome to " + row["UserName"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='../Staffs/Home.aspx'>Khu vực nhân viên</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["UserName"].ToString();
                    }
                }
            }
            else
            {
                string tenkh = "Select * from tbTHONGTINCANHAN where KH_ID='" + makh + "'";
                DataTable dt = cm.getTable(tenkh);
                if (group_id == 1)
                {
                    foreach (DataRow row in dt.Rows)
                    {

                        strLogin += "Welcome to " + row["HoTen"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["HoTen"].ToString();
                    }
                }
                else if (group_id == 2)
                {
                    foreach (DataRow row in dt.Rows)
                    {

                        strLogin += "Welcome to " + row["HoTen"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='../ManagementShop/UserGrant.aspx'>Khu vực admin</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["HoTen"].ToString();
                    }
                }
                else
                {
                    foreach (DataRow row in dt.Rows)
                    {

                        strLogin += "Welcome to " + row["HoTen"].ToString() + " <ul class='dropdown'> ";
                        strLogin += "<li><a href='ThongTinKhachHang.aspx'>Quản lý thông tin</a>";
                        strLogin += "<li><a href='../Staffs/Staff_Home.aspx'>Khu vực nhân viên</a>";
                        strLogin += "<li><a href='DatHangThanhCong.aspx'>Đơn hàng của bạn</a>";
                        strLogin += "<li><a href='DangXuat.aspx'>Đăng xuất</a>";
                        strLogin += "</li></li></li>";
                        strLogin += "</ul>";
                        dangnhap.InnerText = row["HoTen"].ToString();
                    }
                }
            }

            //< li id = "dd" class="wrapper-dropdown-2 cart">
            //   <ul class="dropdown">
            //<li>you have no items in your Shopping cart</li>
            //             </ul>
            //             </li>


        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["UserName"] != null)
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
            }
            Response.Redirect("DanhSachMatHang.aspx", true);
        }

        protected void btn_dangnhap_Click(object sender, EventArgs e)
        {
            string userName = user_name.Value.ToString();
            string Password = MaHoaMD5.Encryptdata(password_c.Value.ToString());
            string sql = "Select * from tbLOGIN where UserName = '" + userName + "' and Password='" + Password + "'";
            DataTable tb = cm.getTable(sql);

            if (tb.Rows.Count != 0)
            {
                Response.Cookies["UserName"].Value = userName;
                Response.Cookies["Password"].Value = Password;
                Session["user"] = userName.ToString();
                Response.Redirect("DanhSachMatHang.aspx");
            }
            else
            {
                string script = "alert(\"Lỗi đăng nhập!\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }
        }

        protected void btn_dangky_Click(object sender, EventArgs e)
        {
            try
            {

                string Tendangnhap = username.Value.ToString();
                string Matkhau = MaHoaMD5.Encryptdata(password1.Value.ToString());
                string Xacnhan_matkhau = MaHoaMD5.Encryptdata(password2.Value.ToString());
                string Hoten = hoten.Value.ToString();
                string sql = "Select * from tbLOGIN";
                DataTable dt = cm.getTable(sql);
                string ten = "";
                foreach (DataRow row in dt.Rows)
                {
                    ten += row["UserName"].ToString();
                }
                if (Tendangnhap == ten)
                {
                    string script = "alert(\"Đã có tên đăng nhập này!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                }
                else
                {

                    if (Matkhau.Equals(Xacnhan_matkhau) == false)
                    {
                        string script = "alert(\"Nhập sai mật khẩu ở xác nhận mật khẩu!\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                    else
                    {
                        string q = "Insert into tbLOGIN(UserName,Password,Group_ID) values('" + Tendangnhap + "','" + MaHoaMD5.Encryptdata(Matkhau) + "',1)";
                        cm.ExecuteNonQuery(q);

                        string data = "Select * from tbLOGIN where UserName='" + Tendangnhap + "' and Password='" + MaHoaMD5.Encryptdata(Matkhau) + "'";
                        DataTable tb = cm.getTable(data);
                        string user_id = "";
                        foreach (DataRow row in tb.Rows)
                        {
                            user_id = row["User_ID"].ToString();
                        }
                        string q1 = "Insert into tbTHONGTINCANHAN(KH_ID,HoTen)values('" + user_id + "',N'" + Hoten + "')";
                        cm.ExecuteNonQuery(q1);
                        string script = "alert(\"Mời bạn đăng nhập!\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                        Response.Redirect("DanhSachMatHang.aspx");

                    }
                }


            }
            catch (SqlException ex)
            {

                throw ex;


            }
        }
    }
}