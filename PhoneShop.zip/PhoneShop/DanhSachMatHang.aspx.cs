﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop
{
    public partial class DanhSachMatHang : System.Web.UI.Page
    {
        COMMON cm = new COMMON();
        DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {
            int page = int.Parse("0" + Request.QueryString["page"]);
            if (page == 0) page = 1;
            if (!IsPostBack)
            {
                string MADM = Request.QueryString.Get("MADM");
                string sql = null;

                if (MADM == null)
                {
                    // sql = "Select * from tbSANPHAM";
                    NapDuLieu(page, 5, 5);
                }
                else
                {
                    string sql1= "Select * from tbSANPHAM where DanhMuc_ID='" + MADM + "'";
                    dt = cm.getTable(sql1);
                    DataList1.DataSource = dt;
                    DataList1.DataBind();
                }

                
                //pager.PageSize = 5;
                //pager.DataSource = dt.DefaultView;

                //pager.BindToControl = DataList1;

                //DataList1.DataSource = pager.DataSourcePaged;
            }

        }

        private void NapDuLieu(int currPage, int recodperpage, int Pagesize)
        {
            string MADM = Request.QueryString.Get("MADM");

            DataSet ds = cm.StoreToDataSet(currPage, recodperpage, Pagesize);
            DataTable dtbData = ds.Tables[0];
            DataTable dtbPhanTrang = ds.Tables[1];

            if (dtbData.Rows.Count > 0)
            {
                DataList1.DataSource = dtbData;
                DataList1.DataBind();
                if (dtbPhanTrang.Rows.Count > 0)
                {
                    Literal1.Text = dtbPhanTrang.Rows[0]["PhanTrang"] + "";
                }
            }
        }
        protected void btn_mua_Click(object sender, EventArgs e)
        {
            Server.Transfer("GioHang.aspx");
        }
    }
}