﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop
{
    public partial class DatHangThanhCong : System.Web.UI.Page
    {
        COMMON cs = new COMMON();
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select User_ID from tbTHONGTINCANHAN,tbLOGIN where UserName='" + username + "' and Password='" + password + "' and tbTHONGTINCANHAN.KH_ID=tbLOGIN.User_ID";
            DataTable tb = cs.getTable(userid);
            string makh = "";
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
            }

            string sql = "Select c.HD_ID,TenSanPham,SoLuongDat,c.Mau,c.DonGia,TongTien,SoLuongDat*c.DonGia as ThanhTien from tbHOADON h inner join tbCHITIETHOADON c on c.HD_ID=h.HD_ID inner join" +
                " tbSANPHAM s on s.SanPham_ID=c.SanPham_ID where User_ID='" + makh + "'";
            dt = cs.getTable(sql);
            grdDonHang.DataSource = dt;
            grdDonHang.DataBind();
            double tong = 0; int soluong = 0;
            
            foreach (DataRow row in dt.Rows)
            {
                tong= Convert.ToDouble(row["TongTien"].ToString());
                soluong = soluong + Convert.ToInt16(row["SoLuongDat"]); 
            }
            
            //Label2.Text = " " + tong + " ";
            //Label5.Text = " " + tong + " ";
        }

        protected void grdDonHang_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select User_ID from tbTHONGTINCANHAN,tbLOGIN where UserName='" + username + "' and Password='" + password + "' and tbTHONGTINCANHAN.KH_ID=tbLOGIN.User_ID";
            DataTable tb = cs.getTable(userid);
            string makh = "";
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
            }

            string sql = "Select c.HD_ID,TenSanPham,SoLuongDat,c.Mau,c.DonGia,TongTien from tbHOADON h inner join tbCHITIETHOADON c on c.HD_ID=h.HD_ID inner join" +
                " tbSANPHAM s on s.SanPham_ID=c.SanPham_ID where User_ID='" + makh + "'";
            dt = cs.getTable(sql);
            grdDonHang.PageIndex = e.NewPageIndex;
            grdDonHang.DataSource = dt;
            grdDonHang.DataBind();
        }

        
        protected void grdDonHang_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select User_ID from tbTHONGTINCANHAN,tbLOGIN where UserName='" + username + "' and Password='" + password + "' and tbTHONGTINCANHAN.KH_ID=tbLOGIN.User_ID";
            DataTable tb = cs.getTable(userid);
            string makh = "";
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
            }
            string sql = "Select c.HD_ID,TenSanPham,SoLuongDat,c.Mau,c.DonGia,TongTien from tbHOADON h inner join tbCHITIETHOADON c on c.HD_ID=h.HD_ID inner join" +
                " tbSANPHAM s on s.SanPham_ID=c.SanPham_ID where User_ID='" + makh + "'";
            dt = cs.getTable(sql);
            double tong = 0; int soluong = 0;
            foreach (DataRow row in dt.Rows)
            {
                tong = Convert.ToDouble(row["TongTien"].ToString());
                soluong = soluong + Convert.ToInt16(row["SoLuongDat"]);
            }
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                Label lbltotal = (Label)e.Row.FindControl("lblTotal");
                lbltotal.Text = soluong.ToString();
                Label lbl_thanhtien = (Label)e.Row.FindControl("lblTotalMoney");
                lbl_thanhtien.Text = tong.ToString();
            }
        }
    }
}
