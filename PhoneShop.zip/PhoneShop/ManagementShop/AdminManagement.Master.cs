﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop.ManagementShop
{
    public partial class AdminManagement : System.Web.UI.MasterPage
    {
        COMMON cm = new COMMON();
        public String strLogin;
        public String strMenu;
     
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["UserName"] == null)
            {
                strLogin += "<li class='nav - item dropdown'><a class='nav - link button'  data-modal='modalOne'>Đăng nhập</a></li>";
            }
            else
            {
                login();
            }

            if (IsPostBack) return;

            strMenu += "<a href ='UserGrant.aspx' class='list-group-item list-group-item-action list-group-item-success'>Phân quyền</a>";
            strMenu += "<a href ='QuanLyTaiKhoan.aspx' class='list-group-item list-group-item-action'>Quản lý tài khoản</a>";
            
        }

        private void login()
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select * from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
            DataTable tb = cm.getTable(userid);
            string makh = ""; int group_id = 0;
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
                group_id = Convert.ToInt16(row["Group_ID"].ToString());
            }

            string tenkh = "Select * from tbTHONGTINCANHAN where KH_ID='" + makh + "'";
            DataTable dt = cm.getTable(tenkh);
            //< li id = "dd" class="wrapper-dropdown-2 cart">
            //   <ul class="dropdown">
            //<li>you have no items in your Shopping cart</li>
            //             </ul>
            //             </li>
            if (group_id != 2)
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
                strLogin += "<li class='nav - item dropdown'><a class='nav - link button '  data-modal='modalOne'>Đăng nhập</a></li>";
                return;
            }
            else
            {
                foreach (DataRow row in dt.Rows)
                {
                    strLogin += "<li class='nav - item dropdown'><a class='nav - link dropdown - toggle' id='navbarDropdown' role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>" + row["HoTen"].ToString() + "</a>";
                    strLogin += "<div class='dropdown-menu dropdown-menu-right' aria-labelledby='navbarDropdown'>";
                    strLogin += "<a class='dropdown-item' href='../DanhSachMatHang.aspx'>Trang chủ sản phẩm</a>";
                    strLogin += "<a class='dropdown-item' href='../DangXuat.aspx'>Đăng xuất</a>";
                    strLogin += "</div></li>";
                }
            }
        }

        protected void btn_dangky_Click(object sender, EventArgs e)
        {
            try
            {

                string Tendangnhap = username.Value.ToString();
                string Matkhau = MaHoaMD5.Encryptdata(password1.Value.ToString());
                string Xacnhan_matkhau = MaHoaMD5.Encryptdata(password2.Value.ToString());
                string Hoten = hoten.Value.ToString();
                string sql = "Select * from tbLOGIN";
                DataTable dt = cm.getTable(sql);
                string ten = "";
                foreach (DataRow row in dt.Rows)
                {
                    ten += row["UserName"].ToString();
                }
                if (Tendangnhap == ten)
                {
                    string script = "alert(\"Đã có tên đăng nhập này!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                }
                else
                {

                    if (Matkhau.Equals(Xacnhan_matkhau) == false)
                    {
                        string script = "alert(\"Nhập sai mật khẩu ở xác nhận mật khẩu!\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        return;
                    }
                    else
                    {
                        string q = "Insert into tbLOGIN(UserName,Password,Group_ID) values('" + Tendangnhap + "','" + MaHoaMD5.Encryptdata(Matkhau) + "',1)";
                        cm.ExecuteNonQuery(q);

                        string data = "Select * from tbLOGIN where UserName='" + Tendangnhap + "' and Password='" + MaHoaMD5.Encryptdata(Matkhau) + "'";
                        DataTable tb = cm.getTable(data);
                        string user_id = "";
                        foreach (DataRow row in tb.Rows)
                        {
                            user_id = row["User_ID"].ToString();
                        }
                        string q1 = "Insert into tbTHONGTINCANHAN(KH_ID,HoTen)values('" + user_id + "',N'" + Hoten + "')";
                        cm.ExecuteNonQuery(q1);
                        string script = "alert(\"Mời bạn đăng nhập!\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                        Response.Redirect("DanhSachMatHang.aspx");

                    }
                }


            }
            catch (SqlException ex)
            {

                throw ex;


            }
        }

        protected void btn_dangnhap_Click(object sender, EventArgs e)
        {
            string userName = user_name.Value.ToString();
            string Password = MaHoaMD5.Encryptdata(password_c.Value.ToString());
            string sql = "Select * from tbLOGIN where UserName = '" + userName + "' and Password='" + Password + "'";
            DataTable tb = cm.getTable(sql);

            if (tb.Rows.Count != 0)
            {
                Response.Cookies["UserName"].Value = userName;
                Response.Cookies["Password"].Value = Password;
                Session["user"] = userName.ToString();
                Server.Transfer("UserGrant.aspx");
            }
            else
            {
                string script = "alert(\"Lỗi đăng nhập!\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }
        }
    }
}
