﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop.ManagementShop
{
    public partial class QuanLyTaiKhoan : System.Web.UI.Page
    {
        COMMON cm = new COMMON();
        public String strMenu;
        protected void Page_Load(object sender, EventArgs e)
        {
            strMenu += "<a href ='UserGrant.aspx' style='width: 240px; height: 50px' class='list-group-item list-group-item-action'>Phân quyền</a>";
            strMenu += "<a href ='QuanLyTaiKhoan.aspx' style='width:240px; height:50px' class='list-group-item list-group-item-action list-group-item-success'>Quản lý tài khoản</a>";
            if (IsPostBack) return;
            docDL();
        }

       private void docDL()
        {
         
            string sql = "Select * from tbLOGIN";
            DataList1.DataSource = cm.getTable(sql);
            DataList1.DataBind();
        }
        protected void btn_xoa_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["UserName"] == null)
            {
                Response.Redirect("../DangNhap.aspx");
            }
            string user_id = ((LinkButton)sender).CommandArgument;
            string sql2 = "Delete from tbTHONGTINCANHAN where KH_ID='" + user_id + "'";
            cm.ExecuteNonQuery(sql2);
            string sql1 = "Delete from tbUSER_GROUP where User_ID='" + user_id + "'";
            cm.ExecuteNonQuery(sql1);
            string sql = "delete from tbLOGIN where User_ID='"+user_id+"'";
            cm.ExecuteNonQuery(sql);
            docDL();
        }

      

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["UserName"] == null)
            {
                Response.Redirect("../DangNhap.aspx");
            }
            string user_id = ((LinkButton)sender).CommandArgument;
            Context.Items["userid"] = user_id;
            Server.Transfer("SuaTaiKhoan.aspx");
        }
    }
}