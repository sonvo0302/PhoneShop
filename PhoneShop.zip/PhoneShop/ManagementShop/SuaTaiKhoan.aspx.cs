﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop.ManagementShop
{
    public partial class SuaTaiKhoan : System.Web.UI.Page
    {
        COMMON cm = new COMMON();
        public String strMenu;
        DataTable dt;
        string user_id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            if (Request.Cookies["UserName"] == null)
            {
                Server.Transfer("../DangNhap.aspx");
            }
            Load_group();
            strMenu += "<a href ='UserGrant.aspx' class='list-group-item list-group-item-action'>Phân quyền</a>";
            strMenu += "<a href ='QuanLyTaiKhoan.aspx' class='list-group-item list-group-item-action list-group-item-success'>Quản lý tài khoản</a>";
            user_id = Context.Items["userid"].ToString();
            string sql = "Select * from tbLOGIN where User_ID='" + user_id + "'";
            dt = cm.getTable(sql);

            foreach (DataRow row in dt.Rows)
            {
                Text1.Value = user_id;
                user_name.Value = row["UserName"].ToString();
                inputPassword.Value = MaHoaMD5.Decryptdata(row["Password"].ToString());
                dropdown_group.SelectedItem.Value = row["Group_ID"].ToString();
            }
        }
        private void Load_group()
        {
            string sql = "Select * from tbGROUP";
            dropdown_group.DataValueField = "Group_ID";
            dropdown_group.DataTextField = "GroupName";
            dropdown_group.DataSource = cm.getTable(sql);
            dropdown_group.DataBind();
        }
        protected void btn_save_Click(object sender, EventArgs e)
        {
            
            string password = MaHoaMD5.Encryptdata(inputPassword.Value.ToString());

            string sql = "Update tbLOGIN set Password='" + password + "',Group_ID='" + dropdown_group.SelectedItem.Value.ToString() + "' where UserName='" + user_name.Value + "'";
            cm.ExecuteNonQuery(sql);
            Server.Transfer("QuanLyTaiKhoan.aspx");
        }

        protected void btn_back_Click(object sender, EventArgs e)
        {
            Response.Redirect("QuanLyTaiKhoan.aspx");
        }
    }
}