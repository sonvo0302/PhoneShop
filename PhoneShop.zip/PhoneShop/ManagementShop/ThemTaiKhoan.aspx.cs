﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop.ManagementShop
{
    public partial class ThemTaiKhoan : System.Web.UI.Page
    {
        COMMON cm = new COMMON();
        public String strMenu;
        DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            Load_group();
            strMenu += "<a href ='UserGrant.aspx' class='list-group-item list-group-item-action'>Phân quyền</a>";
            strMenu += "<a href ='QuanLyTaiKhoan.aspx' class='list-group-item list-group-item-action list-group-item-success'>Quản lý tài khoản</a>";

        }
        private void Load_group()
        {
            string sql = "Select * from tbGROUP";
            dropdown_group.DataValueField = "Group_ID";
            dropdown_group.DataTextField = "GroupName";
            dropdown_group.DataSource = cm.getTable(sql);
            dropdown_group.DataBind();
        }
        protected void btn_save_Click(object sender, EventArgs e)
        {
            string Tendangnhap = user_name.Value.ToString();
            string Matkhau = MaHoaMD5.Encryptdata(inputPassword.Value.ToString());
            string sql = "Select * from tbLOGIN";
            dt = cm.getTable(sql);
            string ten = "";
            foreach (DataRow row in dt.Rows)
            {
                ten += row["UserName"].ToString();
            }
            if (Tendangnhap == ten)
            {
                string script = "alert(\"Đã có tên đăng nhập này!\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

            }
            else
            {

                string q = "Insert into tbLOGIN(UserName,Password,Group_ID) values('" + Tendangnhap + "','" + Matkhau + "','"+dropdown_group.SelectedItem.Value.ToString()+"')";
                cm.ExecuteNonQuery(q);
                Response.Redirect("QuanLyTaiKhoan.aspx");

            }

        }

        protected void btn_back_Click(object sender, EventArgs e)
        {
            Response.Redirect("QuanLyTaiKhoan.aspx");
        }
    }
}