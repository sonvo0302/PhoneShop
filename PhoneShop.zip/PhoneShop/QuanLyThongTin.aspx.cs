﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop
{
    public partial class QuanLyThongTin : System.Web.UI.Page
    {
        DataTable dt;
        COMMON cs = new COMMON();
  
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["UserName"] == null) return;
                //string username = Request.Cookies["UserName"].Value;
                //string password = Request.Cookies["Password"].Value;
                //string userid = "Select User_ID from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
                //DataTable tb = cs.getTable(userid); 
                load_Sothich();
                load_GioiTinh();
                string q = "Select * from tbTHONGTINCANHAN where KH_ID='" + makh() + "'";
                dt = cs.getTable(q);
                foreach (DataRow row in dt.Rows)
                {
                    // Cast instead of using ToString
                    DateTime sdate = (DateTime)row["NgaySinh"];

                    // Then format it as desired. Example:
                    string formattedDate = sdate.ToString("dd-MM-yyyy");


                    txt_TenKhachHang.Text = row["HoTen"].ToString();
                    txt_ngaySinh.Text = formattedDate;
                    txt_DienThoai.Text = row["SoDienThoai"].ToString();
                    txt_Email.Text = row["Email"].ToString();
                    txt_DiaChi.Text = row["DiaChi"].ToString();
                    dropdown_Sothich.SelectedItem.Value = row["SoThich_ID"].ToString();
                }
            }
        }
        public string makh()
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select User_ID from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
            DataTable tb = cs.getTable(userid);
            string makh = "";
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
            }
            return makh;
        }
        private void load_Sothich()
        {
            string q = "Select SoThich_ID from tbTHONGTINCANHAN where KH_ID='" + makh()+"'";
            //string sql;
            //if (cs.getTable(q).Rows.Count > 0)
            //{
                
            //    sql = "select * from tbSOTHICH,tbKHACHHANG where tbKHACHHANG.SoThich_ID=tbSOTHICH.SoThich_ID and KH_ID='" + makh() + "'";
            //}
            //else
            //{
            //    sql = "Select * from tbSOTHICH";
            //}
            
            //string sothich_id = "Select SoThich_ID from tbKHACHHANG";
           
            
                string sql = "select * from tbSOTHICH";

            //string sql = "select * from tbSOTHICH,tbKHACHHANG where tbKHACHHANG.SoThich_ID=tbSOTHICH.SoThich_ID";
            dropdown_Sothich.DataSource = cs.getTable(sql);

            dropdown_Sothich.DataTextField = "TenSoThich";
            dropdown_Sothich.DataValueField = "SoThich_ID";
            dropdown_Sothich.DataBind();
        }
        private void load_GioiTinh()
        {
            string q = "Select GioiTinh_ID from tbTHONGTINCANHAN where KH_ID='" + makh() + "'";
            //string sql;
            //if (cs.getTable(q).Rows.Count > 0)
            //{

            //     sql = "Select * from tbGIOITINH,tbKHACHHANG where tbKHACHHANG.GioiTinh_ID=tbGIOITINH.GioiTinh_ID and KH_ID='" + makh() + "'";
            //}
            //else
            //{
            //    sql = "Select * from tbGIOITINH";
            //}
            string sql = "Select * from tbGIOITINH";
            //string sql = "Select * from tbGIOITINH,tbKHACHHANG where tbKHACHHANG.GioiTinh_ID=tbGIOITINH.GioiTinh_ID and KH_ID='" + makh() + "'";
            drop_gioitinh.DataSource = cs.getTable(sql);

            drop_gioitinh.DataTextField = "TenGioiTinh";
            drop_gioitinh.DataValueField = "GioiTinh_ID";
            drop_gioitinh.DataBind();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //string username = Request.Cookies["UserName"].Value;
            //string password = Request.Cookies["Password"].Value;
            //string userid = "Select User_ID from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
            //DataTable tb = cs.getTable(userid);
            
            //foreach (DataRow row in tb.Rows)
            //{
            //    makh = row["User_ID"].ToString();  
            //}

            string date = Convert.ToDateTime(txt_ngaySinh.Text).ToString("yyyy-MM-dd");
            DateTime sdate = Convert.ToDateTime(date);
            //string strdate = txt_ngaySinh.Text;
            //DateTime date;
            //if (!(DateTime.TryParseExact(strdate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date) ||
            //    DateTime.TryParseExact(strdate, "dd-M-yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date) ||
            //    DateTime.TryParseExact(strdate, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date) ||
            //    DateTime.TryParseExact(strdate, "dd-M-yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date)))
            //{
            //    var dts = strdate.Split('-');
            //    if (dts.Length == 3)
            //    {
            //        var day = Convert.ToInt32(dts[0]);
            //        var month = Convert.ToInt32(dts[1]);
            //        var year = Convert.ToInt32(dts[2]);

            //        date = new DateTime(day, month, year);
            //    }
            //}
            int ngay = int.Parse(sdate.Day.ToString());
            int thang = int.Parse(sdate.Month.ToString());
            int nam = int.Parse(sdate.Year.ToString());

            string sql = "Select*from tbTHONGTINCANHAN where KH_ID='" + makh()+"'";
            dt = cs.getTable(sql);

            string q;
            if (dt.Rows.Count > 0)
            {
               
                q = "Update tbTHONGTINCANHAN set HoTen= N'" + txt_TenKhachHang.Text + "',NgaySinh='" + nam + " / " + thang + " / " + ngay + "',GioiTinh_ID='" + drop_gioitinh.SelectedItem.Value.ToString()+"',SoDienThoai='" + txt_DienThoai.Text + "',Email='" + txt_Email.Text + "',DiaChi= N'" + txt_DiaChi.Text + "', SoThich_ID ='" + dropdown_Sothich.SelectedItem.Value.ToString() + "' where KH_ID ='" + makh() + "'";
            }
            else
            {
                q= "Insert into tbTHONGTINCANHAN(KH_ID,HoTen,NgaySinh,GioiTinh_ID,SoDienThoai,Email,DiaChi,SoThich_ID)values('" + makh()+"',N'" + txt_TenKhachHang.Text + "','" + nam + " / " + thang + " / " + ngay + "','"+ drop_gioitinh.SelectedItem.Value.ToString() + "','" + txt_DienThoai.Text + "','" + txt_Email.Text + "', N'" + txt_DiaChi.Text + "','" + dropdown_Sothich.SelectedItem.Value.ToString() + "')";
            }
           
                cs.ExecuteNonQuery(q);
            Response.Redirect("ThongTinKhachHang.aspx");
        }
    }
}