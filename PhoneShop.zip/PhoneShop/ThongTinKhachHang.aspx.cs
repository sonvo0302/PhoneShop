﻿using PhoneShop.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PhoneShop
{
    public partial class ThongTinKhachHang : System.Web.UI.Page
    {
        COMMON cs = new COMMON();
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["UserName"] == null) return;
                //string username = Request.Cookies["UserName"].Value;
                //string password = Request.Cookies["Password"].Value;
                //string userid = "Select User_ID from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
                //DataTable tb = cs.getTable(userid); 
                string q = "Select * from tbTHONGTINCANHAN where KH_ID='" + makh() + "'";
                dt = cs.getTable(q);
                foreach (DataRow row in dt.Rows)
                {
                    // Cast instead of using ToString
                    DateTime sdate = (DateTime)row["NgaySinh"];

                    // Then format it as desired. Example:
                    string formattedDate = sdate.ToString("dd-MM-yyyy");


                    txt_TenKhachHang.Text = row["HoTen"].ToString();
                    txt_ngaySinh.Text = formattedDate;
                    txt_DienThoai.Text = row["SoDienThoai"].ToString();
                    txt_Email.Text = row["Email"].ToString();
                    txt_DiaChi.Text = row["DiaChi"].ToString();                    
                }
                txt_Gioitinh.Text = load_gioitinh();
                txt_Sothich.Text = load_sothich();
            }
        }
        public string makh()
        {
            string username = Request.Cookies["UserName"].Value;
            string password = Request.Cookies["Password"].Value;
            string userid = "Select User_ID from tbLOGIN where UserName='" + username + "' and Password='" + password + "'";
            DataTable tb = cs.getTable(userid);
            string makh = "";
            foreach (DataRow row in tb.Rows)
            {
                makh = row["User_ID"].ToString();
            }
            return makh;
        }
        private string load_gioitinh()
        {
            string sql = "select TenGioiTinh from tbGIOITINH g inner join tbTHONGTINCANHAN k on k.GioiTinh_ID=g.GioiTinh_ID and KH_ID='"+makh()+"'";
            dt = cs.getTable(sql);
            string gioitinh="";
            foreach(DataRow row in dt.Rows)
            {
                gioitinh = gioitinh + row["TenGioiTinh"];
            }
            return gioitinh;
        }
        private string load_sothich()
        {
            string sql = "select TenSoThich from tbSOTHICH g inner join tbTHONGTINCANHAN k on k.SoThich_ID=g.SoThich_ID and KH_ID='" + makh() + "'";
            dt = cs.getTable(sql);
            string sothich = "";
            foreach (DataRow row in dt.Rows)
            {
                sothich = sothich + row["TenSoThich"];
            }
            return sothich;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("QuanLyThongTin.aspx", true);
        }
    }
}